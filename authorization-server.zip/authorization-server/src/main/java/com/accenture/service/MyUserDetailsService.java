package com.accenture.service;


import com.accenture.model.User;
import com.accenture.repositories.UserRepository;
import com.accenture.user.UserPrinciple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository repo;
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		
		User user = repo.findByUserName(userName);
		
		System.out.println("user: "+user);
		if(user==null) 
			throw new UsernameNotFoundException("Please enter valid details");
		return new UserPrinciple(user);
	}

}
