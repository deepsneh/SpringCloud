package com.accenture.web;

import java.security.Principal;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
    @RequestMapping("/validateUser")
    public Principal user(Principal user) {
        return user;
    }

    @RequestMapping("/validateAdmin")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public Principal admin(Principal user) {
        return user;
    }



}
