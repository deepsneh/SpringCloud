INSERT INTO user (user_name, account_non_expired, account_non_locked, credentials_non_expired,enabled,first_name,last_name,mail_id,password)
VALUES ('root', true, true, true, true, 'pradeep', 'bhati', 'er.pradeep47@gmail.com','$2a$10$QJOu0/F6bGjdvnRVDPCfpuHdI41oSUxoVBVVRsEGsn.ZHZwsAZAie');
INSERT INTO user (user_name, account_non_expired, account_non_locked, credentials_non_expired,enabled,first_name,last_name,mail_id,password)
VALUES ('user', true, true, true, true, 'Snehal', 'Kumbhar', 'testsnehal@gmail.com','$2a$10$QJOu0/F6bGjdvnRVDPCfpuHdI41oSUxoVBVVRsEGsn.ZHZwsAZAie');
INSERT INTO user (user_name, account_non_expired, account_non_locked, credentials_non_expired,enabled,first_name,last_name,mail_id,password)
VALUES ('user1', true, true, true, true, 'preethi', 'chenaboyana', 'testpreethi@gmail.com','$2a$10$QJOu0/F6bGjdvnRVDPCfpuHdI41oSUxoVBVVRsEGsn.ZHZwsAZAie');
INSERT INTO role (id,roles,user_name) VALUES (1,'ROLE_USER','root');
INSERT INTO role (id,roles,user_name) VALUES (2,'ROLE_ADMIN','root');
INSERT INTO role (id,roles,user_name) VALUES (3,'ROLE_USER','user');
INSERT INTO role (id,roles,user_name) VALUES (4,'ROLE_ADMIN','user1');

